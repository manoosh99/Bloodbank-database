/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectdata;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author MCS
 */
public class DON1Controller implements Initializable {

          public void movetoadddonor(ActionEvent event)
  {
        Parent root;
    try {
        root = FXMLLoader.load(getClass().getResource("DONADD.fxml"));
          
        Scene scene = new Scene(root);
        scene.getStylesheets().add("/css/sample.css");
        
        Stage stage= (Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    } catch (IOException ex) {
        Logger.getLogger(DONADDController.class.getName()).log(Level.SEVERE, null, ex);
    }   
  
    
}
          
 public void movetoSearchDon(ActionEvent event)
  {
        Parent root;
    try {
        root = FXMLLoader.load(getClass().getResource("DONSEAR.fxml"));
          
        Scene scene = new Scene(root);
        scene.getStylesheets().add("/css/sample.css");
        
        Stage stage= (Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    } catch (IOException ex) {
        Logger.getLogger(DONSEARController.class.getName()).log(Level.SEVERE, null, ex);
    }   
  
    
}
  public void movetoUpdateDon(ActionEvent event)
  {
        Parent root;
    try {
        root = FXMLLoader.load(getClass().getResource("DONUP1.fxml"));
          
        Scene scene = new Scene(root);
        scene.getStylesheets().add("/css/sample.css");
        
        Stage stage= (Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    } catch (IOException ex) {
        Logger.getLogger(DONUP1Controller.class.getName()).log(Level.SEVERE, null, ex);
    }   
  
    
}
  
 public void movetoDeleteDon(ActionEvent event)
  {
        Parent root;
    try {
        root = FXMLLoader.load(getClass().getResource("DONDELE.fxml"));
          
        Scene scene = new Scene(root);
        scene.getStylesheets().add("/css/sample.css");
        
        Stage stage= (Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    } catch (IOException ex) {
        Logger.getLogger(DONDELEController.class.getName()).log(Level.SEVERE, null, ex);
    }   
  
    
}
 
  public void backtodon(ActionEvent event)
  {
        Parent root;
    try {
        root = FXMLLoader.load(getClass().getResource("Loginsta.fxml"));
          
        Scene scene = new Scene(root);
        scene.getStylesheets().add("/css/sample.css");
        
        Stage stage= (Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    } catch (IOException ex) {
        Logger.getLogger(LoginstaController.class.getName()).log(Level.SEVERE, null, ex);
    }   
  
    
}
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
