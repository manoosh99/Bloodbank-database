/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectdata;


import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author MCS
 */
public class UNIT1Controller implements Initializable {

    @FXML
    private Button addu;
    @FXML
    private Button deleun;
    @FXML
    private Button search5;
    @FXML
    private Button UPDATEUNI;
    @FXML
    private Button bbb;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void addUnit(ActionEvent event) {
  
        Parent root;
    try {
        root = FXMLLoader.load(getClass().getResource("UNITADD.fxml"));
          
        Scene scene = new Scene(root);
        scene.getStylesheets().add("/css/sample.css");
        
        Stage stage= (Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    } catch (IOException ex) {
        Logger.getLogger(UNITADDController.class.getName()).log(Level.SEVERE, null, ex);
    }
  }

    @FXML
    private void UnitDelete(ActionEvent event) {
  
        Parent root;
    try {
        root = FXMLLoader.load(getClass().getResource("UNITDELE.fxml"));
          
        Scene scene = new Scene(root);
        scene.getStylesheets().add("/css/sample.css");
        
        Stage stage= (Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    } catch (IOException ex) {
        Logger.getLogger(UNITDELEController.class.getName()).log(Level.SEVERE, null, ex);
    }
  
    }

    @FXML
    private void movetoSearchUnit(ActionEvent event) {

        Parent root;
    try {
        root = FXMLLoader.load(getClass().getResource("Unisear.fxml"));
          
        Scene scene = new Scene(root);
        scene.getStylesheets().add("/css/sample.css");
        
        Stage stage= (Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    } catch (IOException ex) {
        Logger.getLogger(UnitSearController.class.getName()).log(Level.SEVERE, null, ex);
    }
  }

    @FXML
    private void UnitUPDAT(ActionEvent event) {
 

        Parent root;
    try {
        root = FXMLLoader.load(getClass().getResource("UNITUPD.fxml"));
          
        Scene scene = new Scene(root);
        scene.getStylesheets().add("/css/sample.css");
        
        Stage stage= (Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    } catch (IOException ex) {
        Logger.getLogger(UNITUPDController.class.getName()).log(Level.SEVERE, null, ex);
    }
  }

    @FXML
    private void movetoBACK(ActionEvent event) {
 
        Parent root;
    try {
        root = FXMLLoader.load(getClass().getResource("Loginsta.fxml"));
          
        Scene scene = new Scene(root);
        scene.getStylesheets().add("/css/sample.css");
        
        Stage stage= (Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    } catch (IOException ex) {
        Logger.getLogger(LoginstaController.class.getName()).log(Level.SEVERE, null, ex);
    }
  }
    
}
