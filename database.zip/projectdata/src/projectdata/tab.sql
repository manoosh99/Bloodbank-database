show databases;
create database BloodBankp;
use BloodBankp;
create Table  Donor(DonorID int primary Key ,
DonorMedicalreport varchar(32) ,DonorName varchar(32) ,
 DonorBloodGroup varchar(32) , DonorConectNumber int , DonorAddress varchar(32));
create Table  BloodUnit(code int  primary Key , BloodType varchar(3) , DateB date,DonorID int,
 foreign key (DonorID) references Donor  (DonorID),EmpID int ,
 foreign key (EmpID) references Employee (EmpID));
show tables;
create Table  Employee(EmpID int primary Key ,
EmpUser varchar(32) ,EmpName varchar(32) ,
EmpPassword varchar(32)  ,BloodBankName varchar(32) , 
foreign key (BloodBankName) references BloodBank(BloodBankName));
create Table BloodBank(BloodBankName varchar(32) primary Key ,
BloodBankConectNumber int , BloodBankAddress varchar(32) ,BloodBankDonorsName varchar(32));
 create table destroy(datedest date primary key,code int  ,
 foreign key(code) references BloodUnit (code),BloodBankName varchar(32) ,
 foreign key (BloodBankName) references BloodBank(BloodBankName));







